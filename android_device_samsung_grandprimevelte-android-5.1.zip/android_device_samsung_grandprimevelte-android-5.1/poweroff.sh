setprop sys.powerctl reboot,
sleep 5
